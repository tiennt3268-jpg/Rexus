import type {Context,Config} from '@netlify/functions';
import {getDatabase} from '@netlify/database';
import {randomUUID} from 'node:crypto';
import {getUserFromRequest,unauthorized} from './lib/auth.mts';
import {getFullUser,isSystemAdmin,getEffectiveProjectRole,roleCanManage} from './lib/rbac.mts';
import {logAudit} from './lib/rexus-audit.mts';
const fail=(m:string,s=400)=>Response.json({error:m},{status:s});
const finite=(x:any)=>typeof x==='number'&&Number.isFinite(x)&&x>0&&x<1e15;
export default async(req:Request,_context:Context)=>{
 const user=await getUserFromRequest(req);if(!user)return unauthorized();
 const db=getDatabase(),url=new URL(req.url);const project=url.searchParams.get('project')||'';
 try{
  const b=req.method==='GET'?{}:await req.json().catch(()=>({}));
  const name=String(b.project||project);if(!name)return fail('Project required');
  const me=await getFullUser(db,user.uid);
  const pr=await db.sql`SELECT * FROM projects WHERE name=${name}`;
  const accessible=[];for(const p of pr){if(await getEffectiveProjectRole(db,p.user_id,p.name,user.uid,me?.role))accessible.push(p);}
  if(accessible.length!==1)return fail('Project not found or ambiguous access',403);
  const p=accessible[0];
  const owner=p.user_id;
  if(req.method==='GET'){
   const tx=await db.sql`SELECT * FROM rexus_project_transactions WHERE project_owner_id=${owner} AND project_name=${name} ORDER BY created_at DESC LIMIT 300`;
   const requests=await db.sql`SELECT * FROM rexus_disbursements WHERE project_owner_id=${owner} AND project_name=${name} ORDER BY created_at DESC LIMIT 100`;
   const payments=await db.sql`SELECT pay.* FROM rexus_disbursement_payments pay JOIN rexus_disbursements d ON d.id=pay.request_id WHERE d.project_owner_id=${owner} AND d.project_name=${name}`;
   const currencies=[...new Set([...tx.map((x:any)=>x.currency),...requests.map((x:any)=>x.currency)])];
   const summary=currencies.map(currency=>{
    const confirmed=tx.filter((x:any)=>x.currency===currency && x.status==='Completed');
    const income=confirmed.filter((x:any)=>x.type==='Income').reduce((n:number,x:any)=>n+Number(x.amount),0);
    const expense=confirmed.filter((x:any)=>x.type==='Expense').reduce((n:number,x:any)=>n+Number(x.amount),0);
    const disbursed=payments.filter((x:any)=>requests.some((d:any)=>d.id===x.request_id&&d.currency===currency)).reduce((n:number,x:any)=>n+Number(x.amount),0);
    return {currency,received:income,expenses:expense,net_cash:income-expense,disbursed};
   });
   return Response.json({project:name,approved_budget:p.budget,budget_currency:p.budget_currency||'VND',summary,transactions:tx,disbursements:requests,payments});
  }
  if(req.method!=='POST')return fail('POST required',405);
  const canManage=roleCanManage(await getEffectiveProjectRole(db,owner,name,user.uid,me?.role));
  if(!canManage)return fail('Project finance management access required',403);
  const action=String(b.action||'');
  if(action==='add_transaction'){
   const type=String(b.type||''),currency=String(b.currency||'').toUpperCase(),amount=Number(b.amount);
   if(!['Income','Expense'].includes(type)||!finite(amount)||!/^[A-Z]{3}$/.test(currency))return fail('Invalid transaction');
   const ref=String(b.reference||'').trim();if(!ref)return fail('A unique reference is required');
   const id=randomUUID(),category=String(b.category||'').slice(0,100),desc=String(b.description||'').slice(0,1500);
   try{await db.sql`INSERT INTO rexus_project_transactions(id,project_owner_id,project_name,type,amount,currency,category,description,reference,status,created_by) VALUES (${id},${owner},${name},${type},${amount},${currency},${category},${desc},${ref},'Draft',${user.uid})`;}catch{return fail('Duplicate reference or invalid transaction',409);}
   return Response.json({id,status:'Draft'},{status:201});
  }
  if(action==='confirm_transaction'){
   const id=String(b.id||'');
   const rows=await db.sql`SELECT * FROM rexus_project_transactions WHERE id=${id} AND project_owner_id=${owner} AND project_name=${name}`;
   if(!rows.length)return fail('Transaction not found',404);
   if(rows[0].status!=='Draft'&&rows[0].status!=='Approved')return fail('Transaction already processed',409);
   // Sensitive confirmation is restricted to project owner / System Admin.
   const updated=await db.sql`UPDATE rexus_project_transactions SET status='Completed',confirmed_at=NOW(),approved_by=${user.uid} WHERE id=${id} AND status IN ('Draft','Approved') RETURNING id`;
   if(!updated.length)return fail('Concurrent confirmation conflict',409);
   await db.sql`INSERT INTO rexus_financial_events(id,entity_type,entity_id,actor_id,action) VALUES (${randomUUID()},'transaction',${id},${user.uid},'confirm')`;
   await logAudit(db,{actorId:user.uid,actorName:user.username,action:'finance_confirm',entityType:'transaction',entityId:id,summary:'Confirmed project '+rows[0].type});
   return Response.json({ok:true});
  }
  if(action==='request_disbursement'){
   const amount=Number(b.amount),currency=String(b.currency||'').toUpperCase();
   if(!finite(amount)||!/^[A-Z]{3}$/.test(currency))return fail('Invalid disbursement');
   const id=randomUUID(),purpose=String(b.purpose||'').slice(0,1000),recipient=String(b.recipient||'').slice(0,200);
   await db.sql`INSERT INTO rexus_disbursements(id,project_owner_id,project_name,requested_amount,currency,purpose,recipient,requested_by,status) VALUES (${id},${owner},${name},${amount},${currency},${purpose},${recipient},${user.uid},'Pending Approval')`;
   // Approval Center workflow is required before payments may be made.
   return Response.json({id,status:'Pending Approval',message:'Create an Approval Center request for this disbursement.'},{status:201});
  }
  if(action==='pay_disbursement'){
   const id=String(b.id||''),amount=Number(b.amount),reference=String(b.reference||'').trim();
   if(!finite(amount)||!reference)return fail('Amount and unique payment reference required');
   // Serialize all releases for a project via a row lock; budget and payment
   // totals are recalculated inside the SAME PostgreSQL transaction.
   const client=await db.pool.connect();let status='';
   try{
    await client.query('BEGIN');
    const lockedProject=await client.query('SELECT budget,budget_currency FROM projects WHERE user_id=$1 AND name=$2 FOR UPDATE',[owner,name]);
    if(!lockedProject.rows.length)throw Error('Project unavailable');
    const dr=await client.query('SELECT * FROM rexus_disbursements WHERE id=$1 AND project_owner_id=$2 AND project_name=$3 FOR UPDATE',[id,owner,name]);
    if(!dr.rows.length)throw Error('Disbursement not found');const d=dr.rows[0];
    if(d.currency!==lockedProject.rows[0].budget_currency)throw Error('Disbursement currency does not match project budget currency');
    const approval=await client.query("SELECT 1 FROM rexus_approval_requests WHERE source_type='disbursement' AND source_id=$1 AND status='Approved' LIMIT 1",[id]);
    if(!approval.rows.length)throw Error('Approval Center authorization required');
    const previous=await client.query('SELECT COALESCE(SUM(amount),0)::float AS total FROM rexus_disbursement_payments WHERE request_id=$1',[id]);
    const paid=Number(previous.rows[0].total),approved=Number(d.approved_amount);
    if(!finite(approved)||paid+amount>approved+0.0001)throw Error('Payment exceeds approved amount');
    const all=await client.query('SELECT COALESCE(SUM(pay.amount),0)::float AS total FROM rexus_disbursement_payments pay JOIN rexus_disbursements dis ON dis.id=pay.request_id WHERE dis.project_owner_id=$1 AND dis.project_name=$2 AND dis.currency=$3',[owner,name,d.currency]);
    const budget=Number(lockedProject.rows[0].budget);
    if(!(budget>0)||Number(all.rows[0].total)+amount>budget+0.0001)throw Error('Release exceeds authorized budget');
    await client.query('INSERT INTO rexus_disbursement_payments(id,request_id,amount,reference,recorded_by) VALUES ($1,$2,$3,$4,$5)',[randomUUID(),id,amount,reference,user.uid]);
    status=paid+amount>=approved?'Fully Disbursed':'Partially Disbursed';
    await client.query('UPDATE rexus_disbursements SET status=$1 WHERE id=$2',[status,id]);
    await client.query('INSERT INTO rexus_financial_events(id,entity_type,entity_id,actor_id,action,details) VALUES ($1,$2,$3,$4,$5,$6)',[randomUUID(),'disbursement',id,user.uid,'payment',JSON.stringify({amount,reference})]);
    await client.query('COMMIT');
   }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
   return Response.json({ok:true,status});
  }
  return fail('Unknown action');
 }catch(e:any){return fail('Financial request failed: '+(e.message||'unknown'),500);}
};
export const config:Config={path:'/api/project-financials'};
