import type { Context, Config } from '@netlify/functions';
import { getDatabase } from '@netlify/database';
import { randomBytes, createHash, createPublicKey, timingSafeEqual, verify as verifySig } from 'node:crypto';
import { getUserFromRequest, createSessionToken, sessionCookieHeader, verifyPassword } from './lib/auth.mts';
import { logAudit } from './lib/rexus-audit.mts';

declare const Netlify: { env: { get(name:string):string|undefined } };
const rand = () => randomBytes(32).toString('base64url');
const hash = (s:string) => createHash('sha256').update(s).digest('base64url');
const err = (message:string,status=400) => Response.json({error:message},{status});
function googleConfig() {
 const client=Netlify.env.get('GOOGLE_CLIENT_ID');
 const secret=Netlify.env.get('GOOGLE_CLIENT_SECRET');
 const redirect=Netlify.env.get('GOOGLE_REDIRECT_URI');
 if(!client||!secret||!redirect) throw new Error('Google OAuth is not configured');
 if(!redirect.startsWith('https://') && !redirect.startsWith('http://localhost:')) throw new Error('OAuth callback must use HTTPS');
 return {client,secret,redirect};
}
function jsonPart(part:string){return JSON.parse(Buffer.from(part,'base64url').toString('utf8'));}
async function verifyIdToken(token:string, client:string, nonce:string){
 const parts=token.split('.');
 if(parts.length!==3) throw new Error('Invalid identity token');
 const header=jsonPart(parts[0]), payload=jsonPart(parts[1]);
 if(header.alg!=='RS256'||!header.kid) throw new Error('Unsupported token signature');
 const response=await fetch('https://www.googleapis.com/oauth2/v3/certs');
 if(!response.ok) throw new Error('Cannot verify Google signing keys');
 const keys=(await response.json()).keys;
 const key=keys.find((k:any)=>k.kid===header.kid && k.kty==='RSA' && k.use==='sig');
 if(!key) throw new Error('Unknown Google signing key');
 const valid=verifySig('RSA-SHA256',Buffer.from(parts[0]+'.'+parts[1]),createPublicKey({key,format:'jwk'}),Buffer.from(parts[2],'base64url'));
 if(!valid) throw new Error('Invalid Google signature');
 if(!['https://accounts.google.com','accounts.google.com'].includes(payload.iss)||payload.aud!==client||payload.exp*1000<=Date.now()||payload.iat*1000>Date.now()+60000||payload.nonce!==nonce||!payload.sub) throw new Error('Invalid Google identity claims');
 return payload;
}
function cookieValue(req:Request,name:string){const match=(req.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(name+'='));return match ? match.substring(name.length+1) : '';}
const oauthCookie=(value:string,expire=false)=>`rexus_oauth_state=${value}; Path=/api/google; Secure; HttpOnly; SameSite=Lax; Max-Age=${expire?0:600}`;
function loginRedirect(message:string){return new Response(null,{status:303,headers:{Location:'/?google_error='+encodeURIComponent(message.slice(0,140))}});}
export default async (req:Request,_context:Context) => {
 const url=new URL(req.url); const action=url.pathname.split('/').filter(Boolean).pop();
 try{
  const db=getDatabase();
  if(action==='begin'){
   if(req.method!=='POST') return err('POST required',405);
   const cfg=googleConfig(); const body=await req.json().catch(()=>({}));
   const purpose=body.purpose==='link'?'link':'login'; const current=await getUserFromRequest(req);
   if(purpose==='link'){
    if(!current) return err('Sign in before linking Google',401);
    const rows=await db.sql`SELECT password_hash,status FROM users WHERE id=${current.uid}`;
    if(!rows.length || rows[0].status!=='Active'||!verifyPassword(String(body.password||''),rows[0].password_hash)) return err('Password reauthentication required',403);
   }
   const state=rand(), nonce=rand(), verifier=rand(), userId=purpose==='link' ? current!.uid : null;
   await db.sql`INSERT INTO oauth_pending_states(state_hash,nonce,code_verifier,purpose,user_id) VALUES (${hash(state)},${nonce},${verifier},${purpose},${userId})`;
   const auth=new URL('https://accounts.google.com/o/oauth2/v2/auth');
   for(const [k,v] of Object.entries({client_id:cfg.client,redirect_uri:cfg.redirect,response_type:'code',scope:'openid email profile',state,nonce,code_challenge:hash(verifier),code_challenge_method:'S256',prompt:'select_account'})) auth.searchParams.set(k,v);
   return new Response(JSON.stringify({url:auth.toString()}),{status:200,headers:{'Content-Type':'application/json','Set-Cookie':oauthCookie(state)}});
  }
  if(action==='callback'){
   if(req.method!=='GET') return err('GET required',405);
   if(url.searchParams.get('error')) return loginRedirect('Google sign-in was cancelled');
   const state=url.searchParams.get('state')||'', code=url.searchParams.get('code')||'';
   if(!state||!code) return loginRedirect('Missing OAuth response');
   const bound=cookieValue(req,'rexus_oauth_state');
   if(bound.length!==state.length || !timingSafeEqual(Buffer.from(bound),Buffer.from(state)))return loginRedirect('Unsolicited Google authentication was rejected');
   // Atomic single-use state redemption prevents callback replay.
   const states=await db.sql`UPDATE oauth_pending_states SET consumed_at=NOW() WHERE state_hash=${hash(state)} AND consumed_at IS NULL AND created_at>NOW()-INTERVAL '10 minutes' RETURNING *`;
   if(!states.length) return loginRedirect('Expired or reused Google authentication');
   const pending=states[0], cfg=googleConfig();
   const form=new URLSearchParams({code,client_id:cfg.client,client_secret:cfg.secret,redirect_uri:cfg.redirect,grant_type:'authorization_code',code_verifier:pending.code_verifier});
   const exchange=await fetch('https://oauth2.googleapis.com/token',{method:'POST',body:form,headers:{'Content-Type':'application/x-www-form-urlencoded'}});
   if(!exchange.ok) return loginRedirect('Google token exchange failed');
   const tokens=await exchange.json(); const identity=await verifyIdToken(tokens.id_token,cfg.client,pending.nonce);
   const sub=String(identity.sub), email=String(identity.email||''), avatar=String(identity.picture||'');
   if(pending.purpose==='link'){
    const session=await getUserFromRequest(req);
    if(!session || session.uid!==pending.user_id) return loginRedirect('Your REXUS session expired; please sign in again');
    const existing=await db.sql`SELECT id,status FROM users WHERE id=${session.uid}`;
    if(!existing.length ||existing[0].status!=='Active') return loginRedirect('Inactive REXUS account');
    const taken=await db.sql`SELECT user_id,google_sub FROM user_google_accounts WHERE user_id=${session.uid} OR google_sub=${sub}`;
    if(taken.length) return loginRedirect('Google Account is already linked; disconnect first');
    try { await db.sql`INSERT INTO user_google_accounts(user_id,google_sub,google_email,google_avatar_url) VALUES (${session.uid},${sub},${email},${avatar})`; }
    catch { return loginRedirect('Account link conflict; please retry'); }
    await logAudit(db,{actorId:session.uid,actorName:session.username,action:'google_link',entityType:'account',entityId:session.uid,summary:'Google sign-in linked'});
    return new Response(null,{status:303,headers:{Location:'/?google=connected','Set-Cookie':oauthCookie('',true)}});
   }
   const rows=await db.sql`SELECT u.* FROM user_google_accounts g JOIN users u ON u.id=g.user_id WHERE g.google_sub=${sub}`;
   if(!rows.length) return loginRedirect('This Google account is not linked to any REXUS user. Please sign in with REXUS first.');
   const u=rows[0]; if(u.status!=='Active') return loginRedirect('This REXUS account is inactive');
   await logAudit(db,{actorId:u.id,actorName:u.username,action:'google_login',entityType:'session',entityId:u.id,summary:'Signed in with Google'});
   const headers=new Headers({Location:'/'});headers.append('Set-Cookie',sessionCookieHeader(await createSessionToken(u.id,u.username)));headers.append('Set-Cookie',oauthCookie('',true));return new Response(null,{status:303,headers});
  }
  if(action==='account'){
   const user=await getUserFromRequest(req);if(!user) return err('Not signed in',401);
   if(req.method==='GET'){
    const rows=await db.sql`SELECT google_email,google_avatar_url,linked_at FROM user_google_accounts WHERE user_id=${user.uid}`;
    return Response.json({connected:!!rows.length,account:rows[0]||null});
   }
   if(req.method==='DELETE'){
    const body=await req.json().catch(()=>({}));
    const rows=await db.sql`SELECT password_hash FROM users WHERE id=${user.uid}`;
    if(!rows.length||!verifyPassword(String(body.password||''),rows[0].password_hash)) return err('Confirm your REXUS password before disconnecting',403);
    await db.sql`DELETE FROM user_google_accounts WHERE user_id=${user.uid}`;
    await logAudit(db,{actorId:user.uid,actorName:user.username,action:'google_unlink',entityType:'account',entityId:user.uid,summary:'Disconnected Google sign-in'});
    return Response.json({ok:true});
   }
  }
  return err('Unknown action',404);
 }catch(e:any){return err(e?.message==='Google OAuth is not configured'?'Google sign-in is not configured yet':'Google authentication failed',500);}
};
export const config:Config={path:['/api/google/begin','/api/google/callback','/api/google/account']};
