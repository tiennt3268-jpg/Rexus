import type {Context,Config} from '@netlify/functions';
import {getDatabase} from '@netlify/database';
import {randomUUID} from 'node:crypto';
import {getUserFromRequest,unauthorized} from './lib/auth.mts';
import {getFullUser,isManagerOrAdmin} from './lib/rbac.mts';
import {createNotification} from './lib/notify.mts';
import {logAudit} from './lib/rexus-audit.mts';
const fail=(m:string,s=400)=>Response.json({error:m},{status:s});
const code=()=>randomUUID();
export default async(req:Request,_ctx:Context)=>{
 const user=await getUserFromRequest(req);if(!user)return unauthorized();
 const db=getDatabase(),url=new URL(req.url);
 try{
  if(req.method==='GET'){
   const tab=url.searchParams.get('tab')||'pending';
   const rows=await db.sql`SELECT r.* FROM rexus_approval_requests r WHERE r.requester_id=${user.uid} OR EXISTS(SELECT 1 FROM rexus_approval_steps s WHERE s.request_id=r.id AND s.approver_id=${user.uid}) ORDER BY r.created_at DESC LIMIT 200`;
   const requests=[];
   for(const r of rows){
    const steps=await db.sql`SELECT s.id,s.approver_id,s.sequence_num,s.decision,s.decided_at,s.reason,u.full_name FROM rexus_approval_steps s LEFT JOIN users u ON u.id=s.approver_id WHERE s.request_id=${r.id} ORDER BY sequence_num`;
    const inPending=steps.some((s:any)=>s.approver_id===user.uid&&s.decision==='Pending')&&r.status==='Pending';
    if(tab==='pending'&&!inPending)continue;
    if(tab==='mine'&&r.requester_id!==user.uid)continue;
    if(tab==='approved'&&r.status!=='Approved')continue;
    if(tab==='rejected'&&r.status!=='Rejected')continue;
    requests.push({...r,steps});
   }
   return Response.json({requests});
  }
  if(req.method!=='POST')return fail('POST required',405);
  const body=await req.json();
  if(body.action==='create'){
   // Only backed approval categories are accepted. No dormant business actions can be silently approved.
   if(!['project_budget_review','project_change_review','document_review','project_disbursement'].includes(body.type))return fail('This approval category is not activated');
   const title=String(body.title||'').trim().slice(0,200);
   if(body.type==='project_disbursement'){
    const dis=await db.sql`SELECT id,requested_by,status FROM rexus_disbursements WHERE id=${String(body.source_id||'')}`;
    if(!dis.length||dis[0].status!=='Pending Approval'||dis[0].requested_by!==user.uid)return fail('Not your pending disbursement',403);
   }
   const ids:string[]=[...new Set<string>((Array.isArray(body.approvers)?body.approvers:[]).map((v:any)=>String(v)))];
   const mode=['single','sequential','parallel'].includes(body.mode)?body.mode:'single';
   if(!title||!ids.length||ids.length>15||mode==='single'&&ids.length!==1)return fail('Invalid approval request');
   const valid=await db.sql`SELECT id FROM users WHERE id=ANY(${ids}) AND status='Active'`;
   if(valid.length!==ids.length)return fail('Invalid approver');
   const id=code(),sourceId=String(body.source_id||'').slice(0,100),sourceType=String(body.source_type||'').slice(0,80),payload=JSON.stringify(body.payload||{}).slice(0,3000);
   const client=await db.pool.connect();
   try {
    await client.query('BEGIN');
    await client.query('INSERT INTO rexus_approval_requests(id,request_type,title,payload,source_type,source_id,requester_id,status,mode) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)',[id,body.type,title,payload,sourceType,sourceId,user.uid,'Pending',mode]);
    for(let i=0;i<ids.length;i++)await client.query('INSERT INTO rexus_approval_steps(id,request_id,approver_id,sequence_num) VALUES ($1,$2,$3,$4)',[code(),id,ids[i],mode==='sequential'?i+1:1]);
    await client.query('INSERT INTO rexus_approval_events(id,request_id,actor_id,action,previous_status,new_status) VALUES ($1,$2,$3,$4,$5,$6)',[code(),id,user.uid,'Submit','Draft','Pending']);
    await client.query('COMMIT');
   }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
   for(const who of (mode==='sequential'?ids.slice(0,1):ids))await createNotification(db,{userId:who,type:'approval',title:'Approval required: '+title,entityType:'approval',entityId:id});
   return Response.json({id,status:'Pending'},{status:201});
  }
  if(body.action==='decide'){
   const id=String(body.id||''),decision=String(body.decision||''),reason=String(body.reason||'').trim().slice(0,1000);
   if(!['Approved','Rejected','Changes Requested'].includes(decision))return fail('Invalid decision');
   if(decision!=='Approved'&&!reason)return fail('A reason is required');
   const client=await db.pool.connect();let request:any;let newStatus='Pending';let notifyNext:string|null=null;
   try{
    await client.query('BEGIN');
    const result=await client.query('SELECT * FROM rexus_approval_requests WHERE id=$1 FOR UPDATE',[id]);
    if(!result.rows.length||result.rows[0].status!=='Pending')throw Error('Request not pending or no longer available');
    request=result.rows[0];
    const all=await client.query('SELECT * FROM rexus_approval_steps WHERE request_id=$1 ORDER BY sequence_num FOR UPDATE',[id]);
    const steps=all.rows;
    const mine=steps.find((s:any)=>s.approver_id===user.uid && s.decision==='Pending');
    if(!mine)throw Error('You are not an active approver');
    if(request.mode==='sequential'&&steps.some((s:any)=>s.sequence_num<mine.sequence_num&&s.decision!=='Approved'))throw Error('Earlier approver has not decided');
    await client.query('UPDATE rexus_approval_steps SET decision=$1,reason=$2,decided_at=NOW() WHERE id=$3',[decision,reason,mine.id]);
    const remaining=steps.map((s:any)=>s.id===mine.id?decision:s.decision);
    newStatus=decision==='Approved'?(remaining.every((d:string)=>d==='Approved')?'Approved':'Pending'):decision;
    await client.query('UPDATE rexus_approval_requests SET status=$1,updated_at=NOW() WHERE id=$2',[newStatus,id]);
    await client.query('INSERT INTO rexus_approval_events(id,request_id,actor_id,action,reason,previous_status,new_status) VALUES ($1,$2,$3,$4,$5,$6,$7)',[code(),id,user.uid,decision,reason,'Pending',newStatus]);
    if(request.request_type==='project_disbursement'&&newStatus==='Approved'){
     const applied=await client.query("UPDATE rexus_disbursements SET status='Approved',approved_amount=requested_amount,approved_by=$1 WHERE id=$2 AND status='Pending Approval' RETURNING id",[user.uid,request.source_id]);
     if(!applied.rows.length)throw Error('Financial source status changed; approval rolled back');
    }
    if(request.request_type==='project_disbursement'&&newStatus==='Rejected'){
     await client.query("UPDATE rexus_disbursements SET status='Rejected' WHERE id=$1 AND status='Pending Approval'",[request.source_id]);
    }
    if(newStatus==='Pending'&&request.mode==='sequential')notifyNext=steps.find((s:any)=>s.id!==mine.id&&s.decision==='Pending')?.approver_id||null;
    await client.query('COMMIT');
   }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
   await logAudit(db,{actorId:user.uid,actorName:user.username,action:'approval_decision',entityType:'approval',entityId:id,summary:decision+' '+request.title});
   if(newStatus!=='Pending')await createNotification(db,{userId:request.requester_id,type:'approval',title:request.title+' — '+newStatus,entityType:'approval',entityId:id});
   else if(notifyNext)await createNotification(db,{userId:notifyNext,type:'approval',title:'Approval required: '+request.title,entityType:'approval',entityId:id});
   return Response.json({ok:true,status:newStatus});
  }
  return fail('Unknown action');
 }catch(e:any){return fail('Approval error: '+(e.message||'unknown'),500);}
};
export const config:Config={path:'/api/approval-center'};
