import type {Context,Config} from '@netlify/functions';
import {getDatabase} from '@netlify/database';
import {randomUUID} from 'node:crypto';
import {getUserFromRequest,unauthorized} from './lib/auth.mts';
import {getFullUser,getEffectiveProjectRole,roleCanManage} from './lib/rbac.mts';
const fail=(m:string,s=400)=>Response.json({error:m},{status:s});
export default async (req:Request,_ctx:Context)=>{
 const user=await getUserFromRequest(req);if(!user)return unauthorized();const db=getDatabase();
 try{
  if(req.method==='GET'){
   const project=new URL(req.url).searchParams.get('project');
   if(!project)return fail('Project required');
   const rows=await db.sql`SELECT * FROM projects WHERE name=${project}`;
   const me=await getFullUser(db,user.uid);
   const visible=[];for(const p of rows){if(await getEffectiveProjectRole(db,p.user_id,p.name,user.uid,me?.role))visible.push(p.user_id);}
   if(!visible.length)return fail('Forbidden',403);
   const deps=await db.sql`SELECT d.* FROM rexus_task_dependencies d JOIN tasks t ON t.id=d.successor_id WHERE t.project=${project} AND t.user_id=ANY(${visible})`;
   return Response.json({dependencies:deps});
  }
  if(!['POST','DELETE'].includes(req.method))return fail('Method not supported',405);
  const b=await req.json();const nextId=String(b.successor_id||''),prevId=String(b.predecessor_id||'');
  if(!prevId||!nextId||prevId===nextId)return fail('Invalid dependency');
  const rows=await db.sql`SELECT id,user_id,project FROM tasks WHERE id=${nextId} OR id=${prevId}`;
  const next=rows.find((t:any)=>t.id===nextId),prev=rows.find((t:any)=>t.id===prevId);
  if(!next||!prev||next.user_id!==prev.user_id||next.project!==prev.project)return fail('Tasks must belong to the same project');
  const me=await getFullUser(db,user.uid);
  if(!roleCanManage(await getEffectiveProjectRole(db,next.user_id,next.project,user.uid,me?.role)))return fail('Not permitted',403);
  if(req.method==='POST'){
   const links=await db.sql`SELECT predecessor_id,successor_id FROM rexus_task_dependencies`;
   const adj=new Map<string,string[]>();for(const l of links){adj.set(l.predecessor_id,[...(adj.get(l.predecessor_id)||[]),l.successor_id]);}
   // Adding prev→next creates a cycle if next already reaches prev.
   const todo=[nextId],visited=new Set<string>();while(todo.length){const x=todo.pop()!;if(x===prevId)return fail('Circular dependency');if(visited.has(x))continue;visited.add(x);todo.push(...(adj.get(x)||[]));}
   await db.sql`INSERT INTO rexus_task_dependencies(id,predecessor_id,successor_id) VALUES (${randomUUID()},${prevId},${nextId}) ON CONFLICT(predecessor_id,successor_id) DO NOTHING`;
  }else{
   await db.sql`DELETE FROM rexus_task_dependencies WHERE predecessor_id=${prevId} AND successor_id=${nextId}`;
  }
  // Keep legacy Gantt view in sync; never auto-start/lock/re-date tasks.
  const deps=await db.sql`SELECT predecessor_id FROM rexus_task_dependencies WHERE successor_id=${nextId}`;
  await db.sql`UPDATE tasks SET predecessors=${JSON.stringify(deps.map((r:any)=>({id:r.predecessor_id,type:'FS',lag_days:0})))} WHERE id=${nextId}`;
  return Response.json({ok:true});
 }catch(e:any){return fail('Dependency error: '+(e.message||'unknown'),500);}
};
export const config:Config={path:'/api/task-dependencies'};
