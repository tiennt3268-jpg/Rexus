import type {Context,Config} from '@netlify/functions';
import {getDatabase} from '@netlify/database';
import {randomUUID} from 'node:crypto';
import {getUserFromRequest,unauthorized} from './lib/auth.mts';
import {getFullUser,isSystemAdmin,isManagerOrAdmin,getEffectiveProjectRole,roleCanManage} from './lib/rbac.mts';
const fail=(m:string,s=400)=>Response.json({error:m},{status:s});
const day=(s:string)=>/^\d{4}-\d{2}-\d{2}$/.test(s)&&!isNaN(new Date(s+'T00:00:00Z').valueOf());
function dates(from:string,to:string){const arr:string[]=[];for(let d=new Date(from+'T12:00:00Z');d<=new Date(to+'T12:00:00Z')&&arr.length<367;d.setUTCDate(d.getUTCDate()+1))arr.push(d.toISOString().slice(0,10));return arr;}
export default async (req:Request,_ctx:Context)=>{
 const actor=await getUserFromRequest(req);if(!actor)return unauthorized();
 const db=getDatabase(),url=new URL(req.url);
 try{
  if(req.method==='GET'){
   const from=url.searchParams.get('from')||new Date().toISOString().slice(0,7)+'-01';
   const to=url.searchParams.get('to')||from;
   if(!day(from)||!day(to)||to<from||dates(from,to).length>366)return fail('Invalid date interval (max 366 days)');
   const activeDays=dates(from,to);const users=await db.sql`SELECT id,username,full_name,department,position FROM users WHERE status='Active' ORDER BY full_name`;
   const settings=await db.sql`SELECT * FROM rexus_resource_settings`;
   const off=await db.sql`SELECT * FROM rexus_resource_days_off WHERE day>=${from} AND day<=${to}`;
   const allocations=await db.sql`SELECT a.*,t.task,t.project FROM rexus_resource_allocations a JOIN tasks t ON t.id=a.task_id WHERE a.start_date<=${to} AND a.end_date>=${from}`;
   const actual=await db.sql`SELECT logged_by,COALESCE(SUM(hours),0)::float AS hours FROM worklogs WHERE date>=${from} AND date<=${to} GROUP BY logged_by`;
   const cfgMap=new Map(settings.map((r:any)=>[r.user_id,r]));
   const daysOff=new Set(off.map((r:any)=>String(r.user_id||'*')+'|'+String(r.day).slice(0,10)));
   const actualMap=new Map(actual.map((r:any)=>[r.logged_by,Number(r.hours)||0]));
   const entries=users.map((u:any)=>{
    const cfg:any=cfgMap.get(u.id)||{};let weekdays=[1,2,3,4,5];
    try {const v=JSON.parse(cfg.workdays||'[]');if(Array.isArray(v))weekdays=v.map(Number).filter((x:number)=>x>=0&&x<=6);}catch{}
    const hours=Math.max(0,Math.min(24,Number(cfg.hours_per_day??8)));
    const availableDays=activeDays.filter(s=>weekdays.includes(new Date(s+'T12:00:00Z').getUTCDay())&&!daysOff.has(u.id+'|'+s)&&!daysOff.has('*|'+s));
    const capacity=availableDays.length*hours;
    const work=allocations.filter((a:any)=>a.user_id===u.id).map((a:any)=>{
     const start=String(a.start_date).slice(0,10),end=String(a.end_date).slice(0,10);
     const valid=dates(start,end).filter(s=>weekdays.includes(new Date(s+'T12:00:00Z').getUTCDay()));
     const portion=valid.length?Number(a.planned_hours)/valid.length:0;
     const period=valid.filter(s=>availableDays.includes(s));
     return {...a, planned_in_range:+(period.length*portion).toFixed(2)};
    });
    const planned=work.reduce((sum:number,w:any)=>sum+w.planned_in_range,0);
    const utilization=capacity>0?100*planned/capacity:null;
    return {id:u.id,name:u.full_name||u.username,department:u.department||'',position:u.position||'',working_capacity:capacity,planned_hours:+planned.toFixed(2),actual_hours:actualMap.get(u.id)||0,available_capacity:+(capacity-planned).toFixed(2),utilization:utilization===null?null:+utilization.toFixed(1),status:capacity<=0?'Unavailable':utilization>100?'Overloaded':utilization>=85?'Near Capacity':'Available',allocations:work};
   });
   return Response.json({from,to,employees:entries});
  }
  if(req.method==='POST'||req.method==='DELETE'){
   const actorRow=await getFullUser(db,actor.uid); if(!isManagerOrAdmin(actorRow))return fail('Manager role required',403);
   const b=await req.json();
   if(req.method==='DELETE'){
    if(!b.id)return fail('Missing allocation id');
    const exists=await db.sql`SELECT a.id,t.user_id,t.project FROM rexus_resource_allocations a JOIN tasks t ON t.id=a.task_id WHERE a.id=${String(b.id)}`;
    if(!exists.length)return fail('Allocation not found',404);
    if(!roleCanManage(await getEffectiveProjectRole(db,exists[0].user_id,exists[0].project,actor.uid,actorRow.role)))return fail('Project management access required',403);
    await db.sql`DELETE FROM rexus_resource_allocations WHERE id=${String(b.id)}`;
    return Response.json({ok:true});
   }
   if(b.action==='settings'){
    if(!isSystemAdmin(actorRow))return fail('System Admin access required for employee capacity settings',403);
    const hours=Number(b.hours_per_day),wd=b.workdays;
    if(!b.user_id||!Number.isFinite(hours)||hours<0||hours>24||!Array.isArray(wd)||wd.some((n:any)=>!Number.isInteger(n)||n<0||n>6))return fail('Invalid capacity settings');
    await db.sql`INSERT INTO rexus_resource_settings(user_id,hours_per_day,workdays) VALUES (${b.user_id},${hours},${JSON.stringify(wd)}) ON CONFLICT(user_id) DO UPDATE SET hours_per_day=EXCLUDED.hours_per_day,workdays=EXCLUDED.workdays,updated_at=NOW()`;
    return Response.json({ok:true});
   }
   if(b.action==='day_off'){
    if(!isSystemAdmin(actorRow))return fail('System Admin access required for days off',403);
    if(!day(b.day)||!b.user_id)return fail('Invalid unavailable day');
    await db.sql`INSERT INTO rexus_resource_days_off(id,user_id,day,reason) VALUES (${randomUUID()},${b.user_id},${b.day},${String(b.reason||'').slice(0,200)}) ON CONFLICT(user_id,day) DO NOTHING`;
    return Response.json({ok:true});
   }
   const hours=Number(b.planned_hours);
   if(!b.task_id||!b.user_id||!day(b.start_date)||!day(b.end_date)||b.end_date<b.start_date||!Number.isFinite(hours)||hours<0)return fail('Invalid allocation');
   const task=await db.sql`SELECT t.id,t.user_id,t.project FROM tasks t WHERE t.id=${b.task_id}`;
   if(!task.length)return fail('Task does not exist',404);
   if(!roleCanManage(await getEffectiveProjectRole(db,task[0].user_id,task[0].project,actor.uid,actorRow.role)))return fail('Project management access required',403);
   const targetUser=await db.sql`SELECT id FROM users WHERE id=${String(b.user_id)} AND status='Active'`;
   if(!targetUser.length)return fail('Employee account must be active',400);
   const uid=String(b.user_id),taskId=String(b.task_id),from=String(b.start_date),to=String(b.end_date);
   await db.sql`INSERT INTO rexus_resource_allocations(id,task_id,user_id,planned_hours,start_date,end_date,created_by) VALUES (${randomUUID()},${taskId},${uid},${hours},${from},${to},${actor.uid}) ON CONFLICT(task_id,user_id,start_date,end_date) DO UPDATE SET planned_hours=EXCLUDED.planned_hours,updated_at=NOW()`;
   return Response.json({ok:true});
  }
  return fail('Method not supported',405);
 }catch(e:any){return fail('Resource planning error: '+(e.message||'unknown'),500);}
};
export const config:Config={path:'/api/resource-planning'};
